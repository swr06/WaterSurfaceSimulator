#include "Core/Pipeline.h"

int main() {

	Simulation::Pipeline::StartPipeline();
}